=== The Booking Form - transportation - tbsaasform.zip ===
Tags: booking form,booking integration,booking,taxi booking,shuttle booking,airport transfers,transfers booking
Requires at least: 4.2.2

This plugin will integrate The Booking Form from booking.drivenot.com with your WordPress website.

== Description ==
The Booking Form is a hosted online and mobile booking and dispatch system for Transportation companies - taxi/shuttle/limo/mini cab/phv/chauffeur etc.

With this wordpress plugin you can publish The Booking Form on your WordPress website.

== Installation ==
Normal WordPress installation process. 